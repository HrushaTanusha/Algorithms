#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <map>
#include <set>

using namespace std;

struct Animal {
  string owner;
  string animalType;
  string animalName;
  int age;
};

Animal *createAnimal(const string &owner, const string &animalType, const string &animalName, const string &age) {
  Animal *animal = new(Animal);
  int state = 0;
  animal->owner = owner;
  animal->animalType = animalType;
  animal->animalName = animalName;
  animal->age = stoi(age);
  return animal;
}

vector<Animal *> getDataFromFile(const string &fileName) {
  ifstream input(fileName);
  int sizeOfAnimals;
  input >> sizeOfAnimals;
  input.ignore(1);
  string owner;
  string animalType;
  string animalName;
  string age;
  vector<Animal *> answer;
  for (int i = 0; i < sizeOfAnimals; i++) {
    getline(input, owner, ',');
    getline(input, animalType, ',');
    getline(input, animalName, ',');
    getline(input, age);
    answer.push_back(createAnimal(owner, animalType, animalName, age));
  }
  input.close();
  return answer;
}

void AmountTypesFromEveryone(const vector<Animal *> &list) {
  map<string, set<string>> instrument;
  for (int i = 0; i < list.size(); i++) {
    instrument[list[i]->owner].insert(list[i]->animalType);
  }
  for (auto it = instrument.begin(); it != instrument.end(); it++) {
    cout << it->first << " : " << it->second.size() << endl;
  }
}

void OwnersAndNamesByType(const vector<Animal *> &list) {
  string key;
  cout<<"Please enter type of animal\n";
  cin >> key;
  map<string, set<pair<string, string>>> instrument;
  for (int i = 0; i < list.size(); i++) {
    instrument[list[i]->animalType].insert({list[i]->owner, list[i]->animalName});
  }
  if(instrument[key].empty()){
    cout << "There arent animals with this type\n";
    return;
  }
  for (auto i = instrument[key].begin(); i != instrument[key].end(); i++) {
    cout << "Owner: " << i->first << " Name: " << i->second << endl;
  }
}

void AmountOfTypesWithCurrentName(const vector<Animal *> &list) {
  string key;
  cout<<"Please enter, name of animal\n";
  cin >> key;
  map<string, set<string>> instrument;
  for (int i = 0; i < list.size(); i++) {
    instrument[list[i]->animalName].insert(list[i]->animalType);
  }
  cout << "Types with current name :" << instrument[key].size()<<endl;
}

void OlderestAndYangerest(const vector<Animal *> &list) {
  map<string, pair<Animal *, Animal *>> instrument;
  for (int i = 0; i < list.size(); i++) {
    if (instrument[list[i]->animalType].first == nullptr) {
      instrument[list[i]->animalType].first = list[i];
      instrument[list[i]->animalType].second = list[i];
    }
    if (instrument[list[i]->animalType].first->age < list[i]->age) {
      instrument[list[i]->animalType].first = list[i];
    }
    if (instrument[list[i]->animalType].second->age > list[i]->age) {
      instrument[list[i]->animalType].second = list[i];
    }
  }
  for (auto i: instrument) {
    cout << i.first << " " << i.second.first->age << " " << i.second.first->owner << " " << i.second.first->animalName
         << endl;
    cout << i.first << " " << i.second.second->age << " " << i.second.second->owner << " "
         << i.second.second->animalName << endl;
  }
}

void deleteList(vector<Animal *> &list) {
  for (int i = 0; i < list.size(); ++i) {
    delete (list[i]);
  }
}

void callMenu() {
  cout << "1 - Count types of animals from all owner\n";
  cout << "2 - Find owners and names by type of this animal\n";
  cout << "3 - Count amount of types, which have current name\n";
  cout << "4 - Search youngerest and oldest animal by every type\n";
  cout << "0 - exit\n";
}

int main() {
  vector<Animal *> list = getDataFromFile("input.txt");
  int pointer;
  callMenu();
  cin >> pointer;
  while(pointer){
    switch (pointer) {
      case 1:AmountTypesFromEveryone(list);
        cin >> pointer;
        break;
      case 2:OwnersAndNamesByType(list);
        cin >> pointer;
        break;
      case 3:AmountOfTypesWithCurrentName(list);
        cin >> pointer;
        break;
      case 4:OlderestAndYangerest(list);
        cin >> pointer;
        break;
      case 0:deleteList(list);
        return 0;
      default:
        cin >> pointer;
        break;
    }
  }
}